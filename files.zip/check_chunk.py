#!/usr/bin/env python3
"""
QC for one CellProfiler chunk.

Fails (exit 1) when the run "succeeded" but produced nothing useful:
  * a traceback raised while *running* a module (import-time tracebacks such as
    'No module named MySQLdb' are harmless and ignored);
  * no CSV output, no per-image table, or zero image sets;
  * masks were injected but none were written.
Warns (or fails with --strict) when the number of image sets differs from what the
workflow expected from --group_regex, or when fewer masks than expected exist.

Also copies every CSV into --features-dir (sub-folders flattened with '__').
"""
import argparse
import csv
import json
import os
import re
import shutil
import sys

RUNTIME_MARKERS = ("run_module", "run_with_yield", "run_image_set", "post_run", "prepare_run")
MASK_EXT = {".tif", ".tiff", ".png", ".npy"}


def set_field_limit():
    limit = sys.maxsize
    while True:
        try:
            csv.field_size_limit(limit)
            return
        except OverflowError:
            limit //= 10


def runtime_tracebacks(log_text):
    """Return traceback blocks that come from running the pipeline, not from imports."""
    blocks = re.split(r"(?=Traceback \(most recent call last\))", log_text)
    return [b[:2000] for b in blocks[1:] if any(m in b for m in RUNTIME_MARKERS)]


def read_header_and_count(path):
    with open(path, newline="", encoding="utf-8", errors="surrogateescape") as fh:
        reader = csv.reader(fh)
        header = next(reader, [])
        return header, sum(1 for _ in reader)


def classify(header):
    cols = set(header)
    if "ImageNumber" in cols and "ObjectNumber" in cols:
        return "object"
    if "ImageNumber" in cols:
        return "image"
    return "other"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--outdir", required=True, help="CellProfiler output folder (-o)")
    ap.add_argument("--log", required=True)
    ap.add_argument("--patch-report", required=True)
    ap.add_argument("--expected-sets", type=int, default=-1, help="-1 = unknown")
    ap.add_argument("--features-dir", required=True)
    ap.add_argument("--qc", required=True, help="QC JSON to write")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()
    set_field_limit()

    errors, warnings = [], []
    with open(args.log, encoding="utf-8", errors="replace") as fh:
        log_text = fh.read()
    tbs = runtime_tracebacks(log_text)
    if tbs:
        errors.append(f"{len(tbs)} traceback(s) raised while running modules; first:\n{tbs[0]}")

    os.makedirs(args.features_dir, exist_ok=True)
    tables = {}
    for root, _dirs, files in os.walk(args.outdir):
        for name in sorted(files):
            if not name.lower().endswith(".csv"):
                continue
            src = os.path.join(root, name)
            rel = os.path.relpath(src, args.outdir)
            dest = rel.replace(os.sep, "__")
            shutil.copyfile(src, os.path.join(args.features_dir, dest))
            header, rows = read_header_and_count(src)
            tables[dest] = {"kind": classify(header), "rows": rows, "columns": len(header)}

    image_tables = {k: v for k, v in tables.items() if v["kind"] == "image"}
    n_sets = max((v["rows"] for v in image_tables.values()), default=0)
    if not tables:
        errors.append("CellProfiler wrote no CSV files (no ExportToSpreadsheet output).")
    elif not image_tables:
        errors.append("No per-image table found (a CSV with ImageNumber but no ObjectNumber).")
    elif n_sets == 0:
        errors.append("Per-image table is empty: zero image sets were processed. "
                      "Check the Images/NamesAndTypes filters against your file names.")

    if args.expected_sets > 0 and n_sets and n_sets != args.expected_sets:
        msg = (f"CellProfiler processed {n_sets} image sets but --group_regex predicted "
               f"{args.expected_sets}. The regex may not match how NamesAndTypes builds image sets, "
               "so channels of one site could have been split across chunks.")
        (errors if args.strict else warnings).append(msg)

    with open(args.patch_report, encoding="utf-8") as fh:
        report = json.load(fh)
    n_mask_objects = len(report.get("masks_added", []))
    mask_root = os.path.join(args.outdir, "masks")
    n_masks = 0
    if os.path.isdir(mask_root):
        for _root, _dirs, files in os.walk(mask_root):
            n_masks += sum(1 for f in files if os.path.splitext(f)[1].lower() in MASK_EXT)
    expected_masks = n_sets * n_mask_objects
    if n_mask_objects and n_sets and n_masks == 0:
        errors.append("Mask saving was injected but no mask files were written.")
    elif n_mask_objects and n_masks < expected_masks:
        warnings.append(f"Expected {expected_masks} mask files ({n_sets} sets x {n_mask_objects} objects) "
                        f"but found {n_masks}.")

    qc = {
        "outdir": args.outdir,
        "image_sets": n_sets,
        "expected_image_sets": args.expected_sets,
        "mask_files": n_masks,
        "expected_mask_files": expected_masks,
        "tables": tables,
        "warnings": warnings,
        "errors": errors,
    }
    with open(args.qc, "w", encoding="utf-8") as fh:
        json.dump(qc, fh, indent=2)

    for w in warnings:
        print(f"[check_chunk] WARNING: {w}", file=sys.stderr)
    if errors:
        for e in errors:
            print(f"[check_chunk] ERROR: {e}", file=sys.stderr)
        print("\n----- last 40 lines of the CellProfiler log -----", file=sys.stderr)
        print("\n".join(log_text.splitlines()[-40:]), file=sys.stderr)
        sys.exit(1)
    print(f"[check_chunk] OK: {n_sets} image sets, {len(tables)} tables, {n_masks} mask files")


if __name__ == "__main__":
    main()
