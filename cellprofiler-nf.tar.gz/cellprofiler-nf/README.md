# cellprofiler-nf

Headless CellProfiler as a Nextflow pipeline. You provide **a `.cppipe`, a config and an image folder**; you get
**merged feature tables** and **uint16 segmentation masks for every object set**, even if your `.cppipe`
doesn't save them itself.

```
results/
├── features/              MyExpt_Image.csv, MyExpt_<Object>.csv, ... (all chunks merged) + merge_report.json
├── masks/                 <same sub-folders as input>/<image>_<Object>_mask.tiff  (0 = background, 1..N = objects)
├── cellprofiler_outputs/  anything else your own .cppipe saves (overlays, crops, ...), per chunk
├── pipeline/              patched.cppipe + patch_report.json (every change made to your pipeline)
├── logs/                  CellProfiler log + QC json per chunk
└── pipeline_info/         Nextflow timeline / report / trace
```

## Quick start

Requirements: Nextflow ≥ 24.04 and Docker, Singularity/Apptainer, or a local CellProfiler install.

```bash
tar xzf cellprofiler-nf.tar.gz && cd cellprofiler-nf
# If you copied files individually instead of using the archive:
chmod +x bin/*.py

# 1) Smoke test on the bundled data (6 images, 2 plates)
nextflow run main.nf -profile test,docker

# 2) Your data
nextflow run main.nf -profile docker \
    --pipeline   /path/to/analysis.cppipe \
    --input_dir  /path/to/images \
    --outdir     results \
    --max_cpus 8 --max_memory '32.GB'
```

Use your own config file with `-c my.config`, or keep parameters in YAML with `-params-file params.yaml`:

```yaml
pipeline: /data/exp1/analysis.cppipe
input_dir: /data/exp1/images
chunk_size: 50
group_regex: '^(.+_s\d+)_w\d'
max_memory: 32.GB
```

Add `-resume` to rerun only what changed or failed. Use `-stub` to check the workflow wiring without running CellProfiler.

## How it works

1. **PATCH_PIPELINE** loads your `.cppipe` with CellProfiler's own API. It stops immediately if the pipeline can't be loaded (for example, a missing plugin or a pipeline saved by a newer CellProfiler). It then:
   - adds `ConvertObjectsToImage (uint16)` and `SaveImages` for every object set that isn't already saved. Masks mirror your input folder structure and are **never overwritten**;
   - adds `ExportToSpreadsheet` if your pipeline has no spreadsheet export;
   - removes `CreateBatchFiles`, which would stop a headless run;
   - redirects outputs that point to absolute paths ("Elsewhere…") or to the input folder into the task's output folder.

   Every change is listed in `pipeline/patch_report.json`.
2. **CELLPROFILER** runs `cellprofiler -c -r --file-list` on each chunk of image sets. The input folder is linked in whole, so sub-folders and any metadata taken from folder names are preserved. `check_chunk.py` then fails the task if CellProfiler "succeeded" but produced no CSVs, zero image sets, or no masks.
3. **MERGE_FEATURES** combines each table across chunks into one file. `ImageNumber` restarts at 1 in every chunk, so two columns are added:
   - `CPNF_Chunk`: the chunk each row came from;
   - `CPNF_GlobalImageNumber`: a unique image number across the whole run.

   Join the per-image and per-object tables on `CPNF_GlobalImageNumber`.

## Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `pipeline` | — | `.cppipe` / `.cpproj` (required) |
| `input_dir` | — | Image folder, searched recursively; hidden files are skipped (required) |
| `outdir` | `results` | Output folder |
| `extensions` | tif,tiff,png,… | Image file extensions to pick up (case-insensitive) |
| `chunk_size` | `0` | Image sets per CellProfiler job; `0` = one job (always safe) |
| `group_regex` | — | Defines which files form one image set (see below) |
| `strict_image_count` | `false` | Fail instead of warn if CellProfiler's image-set count differs from the regex prediction |
| `save_masks` | `true` | Add mask saving |
| `mask_objects` | all | e.g. `Nuclei,Cells` |
| `mask_format` | `tiff` | `tiff` / `png` (16-bit) or `npy` (raw labels) |
| `allow_unpatched` | `false` | If patching fails, run the original pipeline instead of stopping |
| `container` | `cellprofiler/cellprofiler:4.2.8` | Use the version your `.cppipe` was saved with |
| `plugins_dir` | — | Folder of CellProfiler plugins |
| `cellprofiler_args` | `''` | Extra CLI flags passed to `cellprofiler` |
| `gzip_features` | `false` | Write `.csv.gz` |
| `publish_mode` | `copy` | `copy` / `symlink` / `link` |
| `max_cpus` / `max_memory` / `max_time` | 16 / 64.GB / 48.h | Hard caps on resource requests. **Set these to your machine or node.** |

Each CellProfiler job requests 1 CPU and 8 GB of memory. Jobs killed for running out of memory or time are retried up to 3 times, with more memory and time on each attempt. Real pipeline errors are not retried.

## Parallelising: `chunk_size` + `group_regex`

CellProfiler builds image sets with NamesAndTypes, for example matching `DNA` and `Actin` images by `Well` and `Site`. If a chunk receives only some of a site's channel files, those image sets break.

The fix is `group_regex`, which keeps all files of one image set in the same chunk. It is applied to each file's path relative to `input_dir`, and its **capture groups** form the image-set key:

| File names | `group_regex` |
|---|---|
| single channel, one file = one set | `'^(.+)$'` |
| `A01_s1_w1.tif`, `A01_s1_w2.tif` (MetaXpress) | `'^(.+?_s\d+)_w\d'` |
| `r01c01f01p01-ch1sk1fk1fl1.tiff` (Opera/Operetta) | `'(r\d+c\d+f\d+p\d+)-ch'` |
| `plate1/B03/site2_DAPI.tif` | `'^(.+/site\d+)_'` |

Each chunk compares CellProfiler's actual image-set count with the regex prediction. A mismatch is logged as a warning (or fails the run with `--strict_image_count true`), which means the regex doesn't match how NamesAndTypes groups your files.

**Keep `chunk_size 0` (no splitting) if your pipeline needs all images in one run**, for example:
- illumination correction with `CorrectIlluminationCalculate` set to "All: across cycles",
- object tracking (`TrackObjects`),
- the `Groups` module,
- `LoadData` with a CSV.

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `Permission denied: bin/patch_cppipe.py` | Run `chmod +x bin/*.py` |
| `Process requirement exceeds available memory` | Set `--max_memory` / `--max_cpus` to what your machine has |
| `CellProfiler reported errors while loading the pipeline` | Plugin missing (`--plugins_dir`) or the `.cppipe` is newer than the container (`--container`). The `DateRevision: 428` header line means 4.2.8. |
| `trying to overwrite ... in headless mode` | Two image sets map to the same output file name. Your own `SaveImages` writes to a flat folder while input files share names across folders. Enable "Create subfolders" in that module or rename the inputs. |
| `Per-image table is empty` | The Images/NamesAndTypes filters in your pipeline exclude all files. Check the filters against your file names and `--extensions`. |
| Image-set count warning | `group_regex` doesn't match how NamesAndTypes groups your files (see above) |
| Docker: `cellprofiler: unrecognized arguments ... bash` | Use the provided `docker` profile, which clears the image's ENTRYPOINT |
| Very slow in containers | CellProfiler sees all host cores. The pipeline pins thread counts to `task.cpus`; don't override those settings. |

## Limitations

- Masks are named after the first input image in NamesAndTypes. Multi-series files (one `.nd2`/`.czi` holding many fields) map several image sets to one file name; the run then **fails rather than overwriting masks**. Save masks with metadata-based names in your own pipeline instead.
- The whole input folder is linked into each task. This is fine on local disks and shared HPC filesystems. On cloud object storage it is copied once per chunk.
- Tested against CellProfiler 4.2.8. CellProfiler 5 changes some module internals; check `patch_report.json` if you switch.
